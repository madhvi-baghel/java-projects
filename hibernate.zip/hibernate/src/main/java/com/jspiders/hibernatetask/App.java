package com.jspiders.hibernatetask;

public class App {

}
