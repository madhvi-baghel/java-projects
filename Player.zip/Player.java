package com.musicplayer.player;
import java.util.Scanner;

import com.musicplayer.songoperation.SongsOperations;

public class Player {
	static boolean loop=true;
	static  SongsOperations s = new SongsOperations();
	static Scanner sc=new Scanner(System.in);
	static int choice;

	public static void main(String[] args) 
	{
		player();
	}
	public static void player() {
		System.out.println("===============MENU======================");
		System.out.println("1. Play Song\n"
				+"2. Add/Remove\n"+
				"3. Edit\n"+
				"4. Exit");
		choice=sc.nextInt();
		
		while(loop)
		{
			switch(choice)
			{
				case 1: {
					System.out.println("1. Play all Songs\n"+ "2. Choose Song to play\n"+
			"3. Play random Song\n"+ "4. Go back");
					choice=sc.nextInt();
				switch(choice)
				{
				     case 1:
				     {
				    	 s.getAllsongs();
				    	 System.out.println("Thank you...");
				    	 player();
					     break;
				     }
				      case 2:
			      	 {
			      		s.getSongs();
			      		System.out.println("Thank you...");
			      		player();
				      break;	
				     }
				     case 3:
				     {
				    	 s.getRandomSong();
				    	 player();
					   break;
				     }
				     case 4:
				     {
				    	 System.out.println("Thank you..");
					   player();
					   break;
				      }
				     default :System.out.println("It is a Invalid\nPlease, Try Again...");
				     choice=1;
				  }
				     break;     }
			   case 2: {
					System.out.println("1. Add Songs\n"+"2. Remove Song\n"+ "3. Go Back");
					choice=sc.nextInt();
					switch(choice)
					{
				
					case 1:
					{
						
						s.add();
						System.out.println("The Song is Successfully added...");
						player();
					    break;	
					}
					case 2:
					{
						s.remove();
						player();
						break;
					}
					case 3:
					{
						player();
						break;
					}
					default :System.out.println("It is a Invalid\nPlease, Try Again...");
					choice=2;
					}
					break;
				}
				case 3:
				{
					System.out.println("1. Name\n"+"2. Singer\n"+"3. Movie\n"+"4. Duration\n"+"5.Go back");
					choice=sc.nextInt();
					
					switch(choice) {
					case 1:
					{
						
						s.editSongname();
						System.out.println("Thank you...");
						player();
						break;
					}
					case 2:
					{
						s.editSinger();
						System.out.println("Thank you...");
						player();
						break;
					
					}
					case 3: 
					{
						s.editMovie();
						player();
						System.out.println("Thank you...");
						break;
					}
					case 4:
					{
						s.editDuration();
						System.out.println("Thank you...");
						player();
						break;
					}
					case 5:
					{
						player();
						break;
					}
					default : System.out.println("It is a Invalid\nPlease, Try Again...");
					choice=3;
					}
					break;
				}
				case 4:
				{
					System.out.println("Thank You.....");
					loop=false;
					break;
				}
				default : System.out.println("It is a Invalid\nPlease, Try Again...");
				player();
				break;
			}
		}
	}
}
