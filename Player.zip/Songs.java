package com.musicplayer.songs;


public class Songs
{
	private int id;
	
	private String Song_name;
	
	private String singer;
	
	private String lyrics;
	
	private String moive;
	
	private double duration;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSong_name() {
		return Song_name;
	}

	public void setSong_name(String song_name) {
		Song_name = song_name;
	}

	public String getSinger() {
		return singer;
	}

	public void setSinger(String singer) {
		this.singer = singer;
	}

	public String getLyrics() {
		return lyrics;
	}

	public void setLyrics(String lyrics) {
		this.lyrics = lyrics;
	}

	public String getMoive() {
		return moive;
	}

	public void setMoive(String moive) {
		this.moive = moive;
	}

	public double getDuration() {
		return duration;
	}

	public void setDuration(double duration) {
		this.duration = duration;
	}
	
	
	public Songs(int id,String name,double duration,String lyrics,String singer,String movie)
	{
		this.id=id;
		this.Song_name=name;
		this.duration=duration;
		this.lyrics=lyrics;
		this.singer=singer;
		this.moive=movie;
	}
	public String toString()
	{
		return "\nId: "+this.id+"\n"+"Song Name: "+ this.Song_name
				+"\n"+"Duration: "+this.duration+"\n"+"Lyrics: "+this.lyrics+"\n"+"Singer: "+this.singer+"\n"+"Moive:"+this.moive;
	}
	
}
