package com.musicplayer.songoperation;
import com.musicplayer.songs.Songs;
import java.util.ArrayList;
import java.util.Scanner;


import java.lang.Math;
public class SongsOperations {
	
	static ArrayList<Songs> n=new  ArrayList<Songs>();
	static Scanner sc=new Scanner(System.in);
	// This method is used to add the song in Songs class.
	public void add()
	{
		System.out.println("Enter the id: ");
		int	id=sc.nextInt();
		sc.nextLine();
	    System.out.println("Enter the Song Name: ");
	    String name=sc.nextLine();
	    System.out.println("Enter the Duration: ");
	    double dur=sc.nextDouble();
	    sc.nextLine();
	    System.out.println("Enter the Lyrics: ");
	    String lr=sc.nextLine();
	    System.out.println("Enter the Singer Name: ");
	    String sin=sc.nextLine();
	    System.out.println("Enter the Moive Name: ");
	    String moive=sc.nextLine();
	  
	    Songs s=new Songs(id,name,dur,lr,sin,moive);
   
		n.add(s);
	}
	//This method is non-static and used to remove the object from the ArrayList of song class
	public void remove()
	{
		if(n.isEmpty())
		{
	    System.out.println("The ArrayList is empty");
		return;
		}
		System.out.println("Enter the id: ");
		int num=sc.nextInt();
		for(Songs songs:n)
		{
			if (songs.getId()==num)
			{
				
				n.remove(songs);
				System.out.println("The Song is Successfully Removed...");
				return;
			}
		}
		System.out.println("The Id is not present..\nPlease,Try Again.....");
		
	}
	//This method is non-static which is used to get the list of get all songs object from songs class 
	public void getAllsongs()
	{
		if(n.isEmpty())
		{
	    System.out.println("The ArrayList is empty");
		return;
		}
		for(int index=0;index<n.size();index++)
		{
			System.out.println(n.get(index));
		}
	}
	//This method is non-static which is used to get the get particular song 
	public void getSongs()
	{
		if(n.isEmpty())
		{
	    System.out.println("The ArrayList is empty");
		return;
		}
		System.out.println("Enter the id : ");
		int num=sc.nextInt();
		for (Songs songs:n)
		{
			if(songs.getId()==num)
			{
				System.out.println("Id:"+songs.getId()+"\nSong Name:"+songs.getSong_name()+"\nSinger:"+songs.getSinger());
				return;
			}
		}
		System.out.println("The Id is not present..\nPlease,Try Again.....");
	}
	//This method is non-static which is used to get random song 
	public void getRandomSong()
	{	
		if(n.isEmpty())
		{
	    System.out.println("The ArrayList is empty");
		return;
		}
		int index=(int) (Math.random()*10);
		if(index<n.size())
		{
		System.out.println(n.get(index));
		 System.out.println("This is your random song\nThank you...");
		}
		else
		{
			getRandomSong();
		}
	}
	//This method is non-static which is used to edit the name of song 
	public void editSongname()
	{
		System.out.println("Enter the id: ");
		int num=sc.nextInt();
		sc.nextLine();
		
		for (Songs songs:n)
		{
			if (songs.getId()==num)
			{
				System.out.println("Enter the Song name: ");
				String Name=sc.nextLine();
				songs.setSong_name(Name);
				System.out.println("Updated Successfull..");
				return;
			}
		}
		System.out.println("The Id is not present..\nPlease,Try Again.....");
			
	}
	//This method is non-static method used to edit the singer name
	public void editSinger()
	{
		System.out.println("Enter the id: ");
		int num=sc.nextInt();
		sc.nextLine();
		for (Songs songs:n)
		{
			if (songs.getId()==num)
			{
				System.out.println("Enter the Singer name: ");
				String Name=sc.nextLine();
				songs.setSinger(Name);
				System.out.println("Updated Successfull..");
				return;
			}
		}	
		System.out.println("The Id is not present..\nPlease,Try Again.....");
	}
	//This method is non-static used to edit the Movie name
	public void editMovie()
	{
		System.out.println("Enter the id: ");
		int num=sc.nextInt();
		sc.nextLine();
		for (Songs songs:n)
		{
			if (songs.getId()==num)
			{
				System.out.println("Enter the Movie name: ");
				String Name=sc.nextLine();
				songs.setMoive(Name);
				System.out.println("Updated Successfull..");
				return;
			}
		}	
		System.out.println("The Id is not present..\nPlease,Try Again.....");
	}
	//This method is non-static used to edit the Duration 
	public void editDuration()
	{
		
		System.out.println("Enter the id: ");
		int num=sc.nextInt();
		sc.nextLine();
		for (Songs songs:n)
		{
			if (songs.getId()==num)
			{
				System.out.println("Enter the Song name: ");
				double value=sc.nextDouble();
				songs.setDuration(value);
				System.out.println("Updated Successfull..");
				return;
			}
		}	
		System.out.println("The Id is not present..\nPlease,Try Again.....");
	}

}
